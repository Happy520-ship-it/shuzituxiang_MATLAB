function varargout = pjimage(varargin)
% PJIMAGE M-file for pjimage.fig
%      PJIMAGE, by itself, creates a new PJIMAGE or raises the existing
%      singleton*.
%
%      H = PJIMAGE returns the handle to a new PJIMAGE or the handle to
%      the existing singleton*.
%
%      PJIMAGE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PJIMAGE.M with the given input arguments.
%
%      PJIMAGE('Property','Value',...) creates a new PJIMAGE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pjimage_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pjimage_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pjimage

% Last Modified by GUIDE v2.5 07-Feb-2020 21:26:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pjimage_OpeningFcn, ...
                   'gui_OutputFcn',  @pjimage_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pjimage is made visible.
function pjimage_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pjimage (see VARARGIN)

% Choose default command line output for pjimage
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
setappdata(handles.figure_pjimage,'img_src',0);%%0��ʾȫ�־��
% UIWAIT makes pjimage wait for user response (see UIRESUME)
% uiwait(handles.figure_pjimage);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Outputs from this function are returned to the command line.
function varargout = pjimage_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function m_file_Callback(hObject, eventdata, handles)
% hObject    handle to m_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function m_file_open_Callback(hObject, eventdata, handles)
% hObject    handle to m_file_open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('������ϵQ1321814823')
%setappdata(handles.figure_pjimage,'img_src',img_src);
% --------------------------------------------------------------------
function m_file_save_Callback(hObject, eventdata, handles)
% hObject    handle to m_file_save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
img_src=getappdata(handles.figure_pjimage,'img_src');

[filename,pathname]=uiputfile('*.bmp');%%����
if isequal(filename,0)||isequal(pathname,0)
    return;
else
    fpath=fullfile(pathname,filename);
end

% --------------------------------------------------------------------
function m_file_exit_Callback(hObject, eventdata, handles)
% hObject    handle to m_file_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(handles.figure_pjimage)

% --------------------------------------------------------------------
function image_chuli_Callback(hObject, eventdata, handles)
% hObject    handle to image_chuli (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function image_chuli_huidu_Callback(hObject, eventdata, handles)
% hObject    handle to image_chuli_huidu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
global img_src
axes(handles.axes_dst);
x=rgb2gray(img_src);
imshow(x);
title('�Ҷȱ任��ͼƬ')
 
 


% --------------------------------------------------------------------
function image_chuli_erzhi_Callback(hObject, eventdata, handles)
% hObject    handle to image_chuli_erzhi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('Q1321814823')


% --------------------------------------------------------------------
function image_chul_xuanzhuan_Callback(hObject, eventdata, handles)
% hObject    handle to image_chul_xuanzhuan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
W=imrotate(img_src,180,'crop');
imshow(W);
title('��ת180���ͼƬ')


% --------------------------------------------------------------------
function image_chuli_jianqie_Callback(hObject, eventdata, handles)
% hObject    handle to image_chuli_jianqie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
I=imcrop(img_src);
imshow(I);
title('����ͼƬ');

% --------------------------------------------------------------------
function image_chul_ruihua_Callback(hObject, eventdata, handles)
% hObject    handle to image_chul_ruihua (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
K=rgb2gray(img_src);
H=fspecial('laplacian');
M=filter2(H,K);
imshow(M)
title('�񻯺��ͼƬ')

% --------------------------------------------------------------------
function image__Callback(hObject, eventdata, handles)
% hObject    handle to image_ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function image_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to image_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
FFT=fft2(img_src);%%%��ά����Ҷ�任
imshow(FFT);
title('FFT�任���ͼƬ');

% --------------------------------------------------------------------
function image_DCT_Callback(hObject, eventdata, handles)
% hObject    handle to image_DCT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
I=rgb2gray(img_src);
K=dct2(I);
imshow(K);
title('DCT�任���ͼƬ')

% --------------------------------------------------------------------
function image_DWT_Callback(hObject, eventdata, handles)
% hObject    handle to image_DWT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
%%axes(handles.axes_dst);
M=rgb2gray(img_src);
[cA,cH,cV,cD]=dwt2(M,'db1'); %use db1 wavelet to discompose the picture
A=upcoef2('a',cA,'db1',1);
H=upcoef2('h',cH,'db1',1);
V=upcoef2('v',cV,'db1',1);
D=upcoef2('d',cD,'db1',1); % coding
figure
subplot(221);image(wcodemat(A,192));
title('����ϸ��ϵ��');
subplot(222);image(wcodemat(H,192));
title('ˮƽϸ��ϵ��');
subplot(223);image(wcodemat(V,192));
title('��ֱϸ��ϵ��');
subplot(224);image(wcodemat(D,192));
title('�Խ�ϸ��ϵ��');
d=idwt2(cA,cH,cV,cD,'db1'); %reconstruct the picture
imshow(d,[]);


% --------------------------------------------------------------------
function image_lbo_Callback(hObject, eventdata, handles)
% hObject    handle to image_lbo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
H=ones(4,4)/16;
K=imfilter(img_src,H);%%%%��ͼƬ���о�ֵ�˲�
imshow(K);
title('��ֵ�˲����ͼƬ')

% --------------------------------------------------------------------
function abc_Callback(hObject, eventdata, handles)
% hObject    handle to abc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function abc_wenli_Callback(hObject, eventdata, handles)
% hObject    handle to abc_wenli (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
[x,y,z]=cylinder;
warp(x,y,z,img_src);
title('��������');

% --------------------------------------------------------------------


% --------------------------------------------------------------------
function abc_bianyuanjiangcitiqu_Callback(hObject, eventdata, handles)
% hObject    handle to abc_bianyuanjiangcitiqu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
B=rgb2gray(img_src);%%��Ҷ�ͼƬ
se=strel('disk',25);%%�����뾶Ϊ25��Բ��
Q=imopen(B,se);%%��ȡ����%%%
 K=imsubtract(B,Q);
 BW1=edge(K,'sobel');%%
 BW2=edge(K,'roberts',0.005); 
 BW3=edge(K,'prewitt'); 
 BW4=edge(K,'log',0.0005);
 %%%%��ʾ���%%%%%%%%%%%%%%%
figure
subplot(121);
imshow(B);
title('ԭʼ�Ҷ�ͼƬ');
subplot(122);
imshow(K);
title('��ȡ���ͼƬ');
figure
subplot(221);
 imshow(BW1);
 title('sobel���Ӽ����');
 subplot(222);
 imshow(BW2);
 title('��ֵΪ0.005��roberts���Ӽ����');
 subplot(223);
 imshow(BW3);
 title('prewitt���Ӽ����');
 subplot(224);
 imshow(BW4);
 title('��ֵΪ0.0005��log���Ӽ����');
 

% --------------------------------------------------------------------
function abc_bianyuan_Callback(hObject, eventdata, handles)
% hObject    handle to abc_bianyuan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
axes(handles.axes_dst);
K=im2bw(img_src)
BW=edge(K,'sobel')
imshow(BW);
title('��Ե��ǿͼƬ');


% --------------------------------------------------------------------
function abc_yasuo_Callback(hObject, eventdata, handles)
% hObject    handle to abc_yasuo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
B=rgb2gray(img_src);
[c,s]=wavedec2(B,2,'db1');
a=appcoef2(c,s,'db1',1);
h=detcoef2('h',c,s,1);
v=detcoef2('v',c,s,1);
d=detcoef2('d',c,s,1);
k=[a h;v d];
b=wcodemat(a,500,'mat');
a1=0.5*b;
subplot(221);
imshow(B)
title('ԭʼ�Ҷ�ͼƬ')
subplot(222);
image(k);
title('�任���Ƶ�ʷ���')
r=appcoef2(c,s,'db1',2);
b=wcodemat(r,500,'mat');
a2=0.25*b;
subplot(223);
image(a1);
title('��һ��ѹ��ͼƬ');
subplot(224);
image(a2);
title('�ڶ���ѹ��ͼƬ');
whos('a1');
whos('a2');


% --------------------------------------------------------------------
function abc_quzao_Callback(hObject, eventdata, handles)
% hObject    handle to abc_quzao (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src
B=rgb2gray(img_src);
J=imnoise(B,'gaussian',0,0.02);
%%M=imnoise(B,'salt & pepper');
subplot(121);
imshow(J);
title('��������ͼƬ');
[a,b,c]=ddencmp('den','wv',J);
K=wdencmp('gbl',J,'sym4',2,a,b,c);
K=uint8(K);
subplot(122);
imshow(K);
title('ȥ����ͼƬ');
